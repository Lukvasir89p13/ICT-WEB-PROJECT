window.addEventListener("load", () =>{
const loader =	document.querySelector(".loader");
loader.classList.add("loader-hidden");
loader.addEventListener("transitionend", () =>{
	document.body.removeChild("loader")
})
})
document.getElementById('slider').addEventListener('click', function() {
    const Slideblock = document.getElementById('Slideblock');
    const isOut = Slideblock.style.right === '0px';
    
    if (isOut) {
        Slideblock.style.right = '-200px'; 
    } else {
        Slideblock.style.right = '0px'; 
    }
});
